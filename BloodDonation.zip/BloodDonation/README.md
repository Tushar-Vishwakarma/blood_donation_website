"# Blood-Donate" 
Database Name: 'blooddonate'
Username: 'root'
Password:''
host: 'localhost'

localhost/view

Use it in your projects.