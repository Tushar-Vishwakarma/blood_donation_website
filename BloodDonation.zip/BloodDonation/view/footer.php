<!--====Developed By Tushar Vishwakarma======-->
<!--====Internshala Internship Exam======-->
<!--====Footer=====-->

<html>
  <head>
	<title>Blood Donation</title>
	<style>


	footer {
    padding: 1px;
    color: white;
    background-color: black;
    clear: left;
    text-align: center;
	padding: 52px;
	weight:100%;
	box-shadow: 0px 0px 31px #888;
     margin-top: 10px;
    border-bottom-right-radius: 10px;
	border-bottom-left-radius: 10px;
    }
	
	    </style>
  </head>
<body>

</div>


<footer>Copyright &copy; Tushar Vishwakarma</footer>
</div>

</body>
</html>