<!--====Developed By Tushar Vishwakarma======-->
<!--====Internshala Internship Exam======-->
<!--====Logout=====-->

<?php	
	session_start();

	session_destroy();
	header('Location: login.php');
?>